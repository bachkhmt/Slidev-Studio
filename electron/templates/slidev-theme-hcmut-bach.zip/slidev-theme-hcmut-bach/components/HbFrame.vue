<script setup lang="ts">
import { computed } from 'vue'
import { configs, useNav, useSlideContext } from '@slidev/client'
import { useSections } from '../utils/sections'

withDefaults(defineProps<{
  /** class riêng của layout (hb-default, hb-cover...) */
  cls?: string
  /** hiện thanh điều hướng section phía trên */
  headline?: boolean
  /** slide có thanh tiêu đề (h1) ngay dưới headline */
  titled?: boolean
}>(), { cls: '', headline: true, titled: true })

const { total } = useNav()
const { $page } = useSlideContext()
const { sections, current } = useSections()

const cfg = configs as Record<string, any>
const author = computed(() => cfg.author ?? '')
const institute = computed(() => cfg.institute ?? '')
const shortTitle = computed(() => cfg.shortTitle ?? cfg.title ?? '')
</script>

<template>
  <div class="slidev-layout hb" :class="cls">
    <div class="hb-bg" aria-hidden="true" />

    <header v-if="headline" class="hb-head">
      <nav class="hb-nav">
        <span
          v-for="(s, i) in sections"
          :key="s.no"
          class="hb-nav-item"
          :class="{ 'is-current': i === current, 'is-dim': current >= 0 && i !== current }"
          :title="s.title"
        >{{ s.short }}</span>
      </nav>
      <div class="hb-fade" :class="{ 'is-untitled': !titled }" />
    </header>

    <main class="hb-main">
      <slot />
    </main>

    <footer class="hb-foot">
      <div class="hb-foot-row">
        <span class="hb-ellipsis">{{ author }}</span>
        <span class="hb-ellipsis hb-right">{{ institute }}</span>
      </div>
      <div class="hb-foot-row">
        <span class="hb-ellipsis">{{ shortTitle }}</span>
        <span class="hb-num">{{ $page }} / {{ total }}</span>
      </div>
    </footer>
  </div>
</template>

<style>
/* Khung chung: nền bản vẽ trường mờ + headline + footline (bám SudaBeamer.sty) */
.slidev-layout.hb {
  position: relative;
  display: flex;
  flex-direction: column;
  height: 100%;
  padding: 0;
  overflow: hidden;
  background: #fff;
}
.hb-bg {
  position: absolute;
  inset: 0;
  z-index: 0;
  background: url('../assets/bk_bg.webp') center / cover no-repeat;
  opacity: 0.5; /* giống \node[opacity=0.5] trong template gốc */
}
.hb-head, .hb-main, .hb-foot { position: relative; z-index: 1; }

/* headline: thanh section (xanh đậm) → chuyển mượt sang thanh tiêu đề (xanh nhạt) */
.hb-nav {
  display: flex;
  justify-content: space-around;
  align-items: center;
  gap: 14px;
  height: 24px;
  padding: 0 14px;
  background: var(--hb-dark);
  color: #fff;
  font-size: 13px;
}
.hb-nav-item { flex: 0 1 auto; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.hb-nav-item.is-current { font-weight: 700; }
.hb-nav-item.is-dim { opacity: 0.55; }
.hb-fade { height: 10px; background: linear-gradient(var(--hb-dark), var(--hb-light)); }
.hb-fade.is-untitled { background: linear-gradient(var(--hb-dark), rgba(3, 43, 145, 0)); }

.hb-main { flex: 1 1 auto; min-height: 0; display: flex; flex-direction: column; }

/* footline: 2 hàng chữ trắng trên nền xanh đậm */
.hb-foot { flex: none; background: var(--hb-dark); color: #fff; font-size: 13px; }
.hb-foot-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 16px;
  height: 19px;
  padding: 0 14px;
}
.hb-ellipsis { min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.hb-right { text-align: right; flex: none; }
.hb-num { flex: none; font-variant-numeric: tabular-nums; }
</style>
