<script setup lang="ts">
import { useSections } from '../utils/sections'

/** \tableofcontents: circles numbered; `highlight` = làm mờ các section khác (show/shaded) */
defineProps<{ highlight?: boolean }>()
const { sections, current, go } = useSections()
</script>

<template>
  <div class="hb-toc">
    <div
      v-for="(s, i) in sections"
      :key="s.no"
      class="hb-toc-item"
      :class="{ 'is-dim': highlight && i !== current }"
      @click="go(s.no)"
    >
      <span class="hb-toc-num">{{ i + 1 }}</span>
      <span class="hb-toc-text">{{ s.title }}</span>
    </div>
  </div>
</template>

<style>
.hb-toc { flex: 1; display: flex; flex-direction: column; justify-content: center; gap: 14px; padding: 0 56px; }
.hb-toc-item { display: flex; align-items: center; gap: 14px; font-size: 25px; line-height: 1.25; cursor: pointer; transition: opacity 0.2s; }
.hb-toc-item.is-dim { opacity: 0.28; }
.hb-toc-num {
  flex: none;
  width: 1.5em;
  height: 1.5em;
  border-radius: 50%;
  background: var(--hb-dark);
  color: #fff;
  font-size: 0.72em;
  font-weight: 700;
  line-height: 1.5em;
  text-align: center;
}
</style>
