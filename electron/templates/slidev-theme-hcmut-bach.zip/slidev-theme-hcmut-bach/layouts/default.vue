<!--
  Frame thường: `# Tiêu đề` = \frametitle.
  Tùy chọn frontmatter:
    subtitle: "1/7: Intensity normalization"   # = \framesubtitle
    align: top                                   # = \begin{frame}[t]  (mặc định: căn giữa dọc như Beamer)
-->
<script setup lang="ts">
import HbFrame from '../components/HbFrame.vue'

defineProps<{ subtitle?: string, align?: 'top' | 'center' }>()
</script>

<template>
  <HbFrame cls="hb-default">
    <div class="hb-content" :class="[subtitle ? 'has-sub' : '', align === 'top' ? 'is-top' : 'is-center']">
      <slot />
      <div v-if="subtitle" class="hb-subtitle">{{ subtitle }}</div>
    </div>
  </HbFrame>
</template>
