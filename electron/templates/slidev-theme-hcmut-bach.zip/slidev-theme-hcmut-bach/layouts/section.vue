<!--
  Slide mở đầu mỗi section (\AtBeginSection + \tableofcontents[sectionstyle=show/shaded]).
  Tên section lấy từ `title`; `short` là tên rút gọn cho thanh điều hướng.
  ---
  layout: section
  title: Kết luận
  short: Kết luận
  ---
-->
<script setup lang="ts">
import HbFrame from '../components/HbFrame.vue'
import SectionList from '../components/SectionList.vue'
</script>

<template>
  <HbFrame cls="hb-section" :titled="false">
    <SectionList highlight />
  </HbFrame>
</template>
