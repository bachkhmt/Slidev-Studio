<!--
  Mục lục đầu bài (\tableofcontents), không làm mờ section nào.
  ---
  layout: agenda
  ---
-->
<script setup lang="ts">
import HbFrame from '../components/HbFrame.vue'
import SectionList from '../components/SectionList.vue'
</script>

<template>
  <HbFrame cls="hb-agenda" :titled="false">
    <SectionList />
  </HbFrame>
</template>
