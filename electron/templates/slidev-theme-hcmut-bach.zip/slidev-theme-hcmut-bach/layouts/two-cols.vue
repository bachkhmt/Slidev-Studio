<!--
  Hai cột dưới thanh tiêu đề.
  ---
  layout: two-cols
  ---
  # Tiêu đề
  ::left::
  nội dung trái
  ::right::
  nội dung phải
-->
<script setup lang="ts">
import HbFrame from '../components/HbFrame.vue'

defineProps<{ subtitle?: string, align?: 'top' | 'center' }>()
</script>

<template>
  <HbFrame cls="hb-two-cols">
    <div class="hb-content" :class="[subtitle ? 'has-sub' : '', align === 'center' ? 'is-center' : 'is-top']">
      <slot />
      <div class="hb-cols">
        <div class="hb-col"><slot name="left" /></div>
        <div class="hb-col"><slot name="right" /></div>
      </div>
      <div v-if="subtitle" class="hb-subtitle">{{ subtitle }}</div>
    </div>
  </HbFrame>
</template>

<style>
.hb-cols { display: grid; grid-template-columns: 1fr 1fr; gap: 28px; }
.hb-col > :first-child { margin-top: 0; }
</style>
