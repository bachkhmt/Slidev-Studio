import { computed } from 'vue'
import { useNav, useSlideContext } from '@slidev/client'

/**
 * Danh sách section = mọi slide có `layout: section`.
 * Tương đương \section{} + thanh điều hướng (smoothbars) của Beamer.
 */
export function useSections() {
  const { slides, go } = useNav()
  const { $page } = useSlideContext()

  const sections = computed(() =>
    slides.value
      .filter(s => s.meta.slide?.frontmatter?.layout === 'section')
      .map((s) => {
        const fm = s.meta.slide.frontmatter
        const title: string = fm.title ?? s.meta.slide.title ?? ''
        return { no: s.no, title, short: fm.short ?? title }
      }),
  )

  // section hiện tại = section gần nhất nằm ở/ trước slide đang render
  const current = computed(() => {
    let idx = -1
    sections.value.forEach((s, i) => {
      if (s.no <= $page.value)
        idx = i
    })
    return idx
  })

  return { sections, current, go }
}
