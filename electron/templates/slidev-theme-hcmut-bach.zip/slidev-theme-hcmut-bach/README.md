# slidev-theme-hcmut-bach

Theme Slidev chuyển thể từ template Beamer `SudaBeamer.sty` (xanh HCMUT, nền bản vẽ trường mờ, footline 2 hàng).

## Chạy thử

```bash
npm install
npm run dev          # mở example.md
npm run export       # xuất PDF (cần: npx playwright install chromium)
```

## Dùng trong deck khác

```yaml
---
theme: /đường/dẫn/tới/slidev-theme-hcmut-bach   # hoặc ../slidev-theme-hcmut-bach
layout: cover
title: Tên bài trình bày
shortTitle: Tên rút gọn cho footer   # tùy chọn
author: Group 07
institute: Ho Chi Minh University of Technology, HCMUT
date: September 15, 2026
---
```

Muốn dùng qua npm: `npm publish` rồi `theme: hcmut-bach`.

## Layout

| Layout | Tương đương Beamer | Ghi chú |
|---|---|---|
| `cover` | `\titlepage` | đọc `title`, `institute`, `author`, `date` từ headmatter |
| `agenda` | `\tableofcontents` | liệt kê mọi slide `layout: section` |
| `section` | `\section` + `\AtBeginSection` | `title:` = tên section, `short:` = tên ngắn trên thanh điều hướng |
| `default` | `\begin{frame}{...}` | `# Tiêu đề`; `subtitle:` = `\framesubtitle`; `align: top` = `[t]` (mặc định căn giữa dọc như Beamer) |
| `two-cols` | `columns` | dùng `::left::` và `::right::`, `# Tiêu đề` nằm trên cùng |

Các layout khác của Slidev (`center`, `image-right`...) không có khung theme; dùng 5 layout trên cho slide chuẩn.

## Component

```md
<Block title="Mục tiêu chung">…</Block>
<Block type="alert" title="Vấn đề đặt ra">…</Block>   <!-- alertblock -->
<Block type="example" title="Ví dụ">…</Block>          <!-- exampleblock -->
```

## Lưu ý

- Khổ mặc định **4:3** (giống `\documentclass{beamer}`), `canvasWidth: 800`. Đổi bằng `aspectRatio: 16/9` trong headmatter.
- Font Source Sans 3 (hỗ trợ tiếng Việt) tự tải từ Google Fonts; cần mạng lần chạy đầu.
- Công thức viết bằng KaTeX (`$...$`, `$$...$$`, `\boxed`, `\operatorname`, `\mathbb` đều dùng được).
- Ảnh nền đã nén từ 6.3 MB xuống 86 KB (`assets/bk_bg.webp`), độ mờ 0.5 như template gốc.
